// Jvdroid-main: 
package com.example.financeapp.model;

public class Transaction {
    private int id;
    private String type; // income / expense
    private String category;
    private double amount;
    private String date;

    public Transaction(int id, String type, String category, double amount, String date) {
        this.id = id;
        this.type = type;
        this.category = category;
        this.amount = amount;
        this.date = date;
    }

    // Getters
    public int getId() { return id; }
    public String getType() { return type; }
    public String getCategory() { return category; }
    public double getAmount() { return amount; }
    public String getDate() { return date; }
}