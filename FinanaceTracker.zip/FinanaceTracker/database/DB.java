package com.example.financeapp.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = \"finance.db\";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(\"CREATE TABLE transactions(\" +
                \"id INTEGER PRIMARY KEY AUTOINCREMENT,\" +
                \"type TEXT,\" +
                \"category TEXT,\" +
                \"amount REAL,\" +
                \"date TEXT)\");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(\"DROP TABLE IF EXISTS transactions\");
        onCreate(db);
    }
}