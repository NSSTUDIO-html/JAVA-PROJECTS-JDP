package com.example.bank.service;

import com.example.bank.model.User;
import com.example.bank.model.Transaction;
import com.example.bank.repository.UserRepository;
import com.example.bank.repository.TransactionRepository;
import org.springframework.stereotype.Service;

@Service
public class BankService {

    private final UserRepository userRepo;
    private final TransactionRepository txnRepo;

    public BankService(UserRepository userRepo, TransactionRepository txnRepo) {
        this.userRepo = userRepo;
        this.txnRepo = txnRepo;
    }

    public User createUser(User user) {
        return userRepo.save(user);
    }

    public User deposit(Long userId, double amount) {
        User user = userRepo.findById(userId).orElseThrow();
        user.setBalance(user.getBalance() + amount);
        return userRepo.save(user);
    }

    public User withdraw(Long userId, double amount) {
        User user = userRepo.findById(userId).orElseThrow();

        if (user.getBalance() < amount) {
            throw new RuntimeException(\"Insufficient Balance\");
        }

        user.setBalance(user.getBalance() - amount);
        return userRepo.save(user);
    }

    public String transfer(Long fromId, Long toId, double amount) {
        User sender = userRepo.findById(fromId).orElseThrow();
        User receiver = userRepo.findById(toId).orElseThrow();

        if (sender.getBalance() < amount) {
            throw new RuntimeException(\"Insufficient Balance\");
        }

        sender.setBalance(sender.getBalance() - amount);
        receiver.setBalance(receiver.getBalance() + amount);

        userRepo.save(sender);
        userRepo.save(receiver);

        Transaction txn = new Transaction();
        txn.setSenderId(fromId);
        txn.setReceiverId(toId);
        txn.setAmount(amount);

        txnRepo.save(txn);

        return \"Transfer Successful\";
    }
}