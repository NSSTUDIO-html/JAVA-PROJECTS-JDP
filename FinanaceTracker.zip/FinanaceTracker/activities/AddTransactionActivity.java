package com.example.financeapp.activities;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.example.financeapp.database.DBHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;

public class AddTransactionActivity extends AppCompatActivity {

    EditText amountInput, categoryInput;
    Spinner typeSpinner;
    Button saveBtn;

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction);

        amountInput = findViewById(R.id.amount);
        categoryInput = findViewById(R.id.category);
        typeSpinner = findViewById(R.id.type);
        saveBtn = findViewById(R.id.saveBtn);

        dbHelper = new DBHelper(this);

        saveBtn.setOnClickListener(v -> {
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(\"type\", typeSpinner.getSelectedItem().toString());
            values.put(\"category\", categoryInput.getText().toString());
            values.put(\"amount\", Double.parseDouble(amountInput.getText().toString()));
            values.put(\"date\", \"2026-01-01\");

            db.insert(\"transactions\", null, values);

            Toast.makeText(this, \"Saved\", Toast.LENGTH_SHORT).show();
        });
    }
}