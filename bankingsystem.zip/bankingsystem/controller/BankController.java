package com.example.bank.controller;

import com.example.bank.model.User;
import com.example.bank.service.BankService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(\"/api/bank\")
@CrossOrigin(\"*\")
public class BankController {

    private final BankService service;

    public BankController(BankService service) {
        this.service = service;
    }

    @PostMapping(\"/user\")
    public User createUser(@RequestBody User user) {
        return service.createUser(user);
    }

    @PostMapping(\"/deposit/{id}\")
    public User deposit(@PathVariable Long id, @RequestParam double amount) {
        return service.deposit(id, amount);
    }

    @PostMapping(\"/withdraw/{id}\")
    public User withdraw(@PathVariable Long id, @RequestParam double amount) {
        return service.withdraw(id, amount);
    }

    @PostMapping(\"/transfer\")
    public String transfer(@RequestParam Long fromId,
                           @RequestParam Long toId,
                           @RequestParam double amount) {
        return service.transfer(fromId, toId, amount);
    }
}